# Install the info files for this package
echo "executing doinst.sh"
CWD=`pwd`
if [ -r /pkg/kernel.org/kernel/2.6.34/linux-2.6.34 ]
then
cd /usr/src/
ln -sf /pkg/kernel.org/kernel/2.6.34/linux-2.6.34 
fi

if [ -r /pkg/kernel.org/kernel/2.6.34/modules ]
then
cd /lib/
 ln -sf /pkg/kernel.org/kernel/2.6.34/modules
fi


if [ -r /pkg/kernel.org/kernel/2.6.34/System.map ]
 then
 cd /boot/
  ln -sf /pkg/kernel.org/kernel/2.6.34/System.map
  ln -s  /pkg/kernel.org/kernel/2.6.34/vmlinuz 
  ln -s  /pkg/kernel.org/kernel/2.6.34/initrd-tree 
  ln -s  /pkg/kernel.org/kernel/2.6.34/initrd.gz 
 fi

#if [ -r /pkg/Kernel.org/Kernel/2.6.34 ]
# then
#  cd /pkg
#rm -rf Kernel.org
# fi

